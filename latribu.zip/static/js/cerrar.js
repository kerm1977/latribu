function closeWin(){
	document.getElementById("msn").style.display ="none";
}


// Referencia
// https://www.youtube.com/watch?v=KJbLiV6Y9sY