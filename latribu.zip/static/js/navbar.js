function mostrarBarra(){
    const sidebar = document.querySelector(".sidebar")
    sidebar.style.display ="flex"   
}


function cerrarBarra(){
    const sidebar = document.querySelector(".sidebar")
    sidebar.style.display ="none"   
}